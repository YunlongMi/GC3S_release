package com.GC3S.utils;

/**
 * @ClassName: PropertiesUtil
 * @Description:Set some related parameters of gC3S.
 * @author Yunlong.MI
 * @date Feb. 20, 2021
 * @since jdk1.8
 */
public class ParametersUtil {
	/** The path for data. */
	public static String train_path = "./data/train[1].csv";
	public static String test_path = "./data/test[1].csv";

	/** gC3S or gC3S_E: error corrects rate for concept drift detection. */
	public static String methodType = "gC3S_E";
	/** Show the results by bachSize or overall accuracies.*/
	public static String showResult="overall";// bachSize or overall 
	
	/** Three required parameters */
	/** Lambda: concept falling space, the $\lambda $ value and P */
	public static int lambda  = 8; // it represents lambda = 8/10
	public static double P = 1;// concept falling, P=1 or P=1/10
	/** MaxSize: The size of concept spaces for each class. */
	public static int conceptSZ =10;
	/** Chunk size: The size of each data chunk. */
	public static int C =100;
	/** Delta_{d}: For gC3S_E, when isConceptDrift > conceptDriftTheta, concept drift occurs. */
	public static double conceptDriftTheta=3.14;//[0,3.15], 3.15>PI
}
