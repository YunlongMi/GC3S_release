package com.GC3S.utils;

import java.util.Vector;

/**
 * @className Metrics
 * @author Dr. YunlongMi
 * @details Metrics for a method
 * @date Mar. 1, 2021
 * @version V1.1
 * @since jdk1.8
 */
public class Metrics {

	public Vector<Object> getConfuMatrix(int[][] confuMatrix) {
		Vector<Object> result = new Vector<Object>();
		int correct = 0;
		double sum = 0.0;
		/** The sum of rows */
		int[] rowSum = new int[confuMatrix.length];
		for (int row = 0; row < confuMatrix.length; ++row) {
			for (int col = 0; col < confuMatrix.length; ++col) {
				rowSum[row] += confuMatrix[row][col];
				if (row == col) {// for correct
					correct += confuMatrix[row][col];
				}
			} // end_of_for
		} // end_of_for
		/** The sum of cols */
		int[] colSum = new int[confuMatrix.length];
		for (int col = 0; col < confuMatrix.length; ++col) {
			for (int row = 0; row < confuMatrix.length; ++row) {
				colSum[col] += confuMatrix[row][col];
				sum += confuMatrix[row][col];
			} // end_of_for
		} // end_of_for

		double acc = correct / sum;
		// Precision：TP/colSum; Recall：TP/rowSum
		double Macro_P = 0, P = 0, Macro_R = 0, R = 0, Macro_F1 = 0, F1_Measure = 0;
		for (int row = 0; row < confuMatrix.length; row++) {
			for (int col = 0; col < confuMatrix.length; col++) {
				if (row == col) {
					if (colSum[row] != 0.0) {
						P = confuMatrix[row][col] / (double) colSum[row];
					} else {// TP+FP=0
						P = 0.0;
					} // end_of_if
					if (rowSum[row] != 0.0) {
						R = confuMatrix[row][col] / (double) rowSum[row];
					} else {// TP+FN=0
						R = 0.0;
					} // end_of_if
					if ((P + R) != 0.0) {
						F1_Measure = 2 * P * R / (double) (P + R);
					} else {
						F1_Measure = 0.0;
					}
					// System.out.print(
					// row + ":" + " Precision=" + P + " " + "Recall=" + R + " " + "F1-Measure=" + F1_Measure);
				} // end_of_if
			} // end_of_for
			System.out.println();
			Macro_P += P;
			Macro_R += R;
			Macro_F1 += F1_Measure;
		} // end_of_for
		result.add(acc);// accuracy
		result.add(Macro_P / confuMatrix.length);// precision
		result.add(Macro_R / confuMatrix.length);// recall
		result.add(Macro_F1 / confuMatrix.length);// F1_score
		return result;
	}// end_of_getConfuMatrix
}// end_of_Metrics
