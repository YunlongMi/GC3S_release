package com.GC3S.main;

import java.util.Vector;
import com.GC3S.trainS.GC3S;
import com.GC3S.utils.LoadDataUtil;
import com.GC3S.utils.ParametersUtil;

/**
 * @ClassName: RunMethod
 * @Description: Entry our method
 * @author Dr. Yunlong Mi
 * @date Sep. 15, 2022
 * @version Granular concept-cognitive computing system (gC3S) <br/>
 * @since jdk1.8
 */
public class RunMethod {

	public static void main(String[] args) throws Exception {
		for (int index = 1; index <= 1; ++index) {
			/** Load datasets */
			long s1 = System.currentTimeMillis();
			Vector<Object> train_vec = LoadDataUtil
					.loadData(ParametersUtil.train_path.replace("indexNum", String.valueOf(index)));
			/** stream 1 */
			Vector<Object> test_vec = LoadDataUtil.load2Data(
					ParametersUtil.train_path.replace("indexNum", String.valueOf(index)),
					ParametersUtil.test_path.replace("indexNum", String.valueOf(index)));
//			/** stream 2 */
//			Vector<Object> test_vec = LoadDataUtil
//					.loadData2(ParametersUtil.test_path.replace("indexNum", String.valueOf(index)));

			long e1 = System.currentTimeMillis();
			System.err.println("Load dataset：" + (e1 - s1) + "(ms)");

			/** Instantiation system, 实例化系统 */
			GC3S gc3s = new GC3S(train_vec);
			/** Initial system, 系统初始化 */
			long s2 = System.currentTimeMillis();
			gc3s.initialS();
			long e2 = System.currentTimeMillis();
			System.err.println("Initial system：" + (e2 - s2) + "(ms)");

			/** Evaluating and updating system, 系统动态更新与评估 */
			long s3 = System.currentTimeMillis();
			gc3s.evaluateS(test_vec);
			long e3 = System.currentTimeMillis();
			System.err.println("Evaluating system：" + (e3 - s3) + "(ms)");
		} // end_of_for_20_loops
	}// end_of_main
}
