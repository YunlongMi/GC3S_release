package com.GC3S.trainS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ExecutionException;

import com.GC3S.evaluateS.UpdateAllLabGC3S;
import com.GC3S.evaluateS.UpdateAllLabGC3S_E;
import com.GC3S.initialS.InitalMethod;
import com.GC3S.utils.ParametersUtil;

/**
 * @author YunlongMi
 * @version V1.1
 * @date Feb. 21, 2021
 * @details GC3S
 */
public class GC3S {
	private Vector<Object> train_vec;
	private ArrayList<Map<double[], Set<Integer>>> tConceptPoolList;

	public GC3S(Vector<Object> train_vec) {
		this.train_vec = train_vec;
	}// end_of_CCCS

	/**
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @details Constructing concept spaces by means of selecting an theta.
	 */
	@SuppressWarnings("unchecked")
	public void initialS() throws IOException, InterruptedException, ExecutionException {
		InitalMethod IM = new InitalMethod(train_vec);// forms concept spaces based on a train dataset
		Vector<Object> vec = IM.initialConceptPoolByTheta();
		tConceptPoolList = (ArrayList<Map<double[], Set<Integer>>>) vec.get(0);// gets concept pool
	}// end_of_initialS

	/**
	 * @param test_vec
	 * @throws ExecutionException
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @details Concept generalization
	 */
	public void evaluateS(Vector<Object> test_vec)
			throws InterruptedException, ExecutionException, ClassNotFoundException, IOException {
		int[] train_Y = (int[]) train_vec.get(1);// label information for training dataset
		if (ParametersUtil.methodType.equals("gC3S")) {
			UpdateAllLabGC3S lC3S = new UpdateAllLabGC3S(tConceptPoolList, test_vec, train_Y);
			lC3S.learningC3S();
			tConceptPoolList.clear();
			test_vec.clear();
		} else {
			UpdateAllLabGC3S_E lC3S = new UpdateAllLabGC3S_E(tConceptPoolList, test_vec, train_Y);
			lC3S.learningC3S();
			tConceptPoolList.clear();
			test_vec.clear();
		} // end_of_if
	}// end_of_evaluate
}
