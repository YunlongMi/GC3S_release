package com.GC3S.commonTools;

import java.util.Map;
import java.util.Set;
import org.jblas.ComplexDoubleMatrix;
import org.jblas.DoubleMatrix;
import org.jblas.Eigen;
import com.GC3S.utils.MathMethodUtil;
import com.GC3S.utils.ParametersUtil;

/**
 * @author MYL
 * @date Feb. 24, 2021
 */
public class PCADrift {

	/**
	 * @param dataChunk1
	 * @param dataChunk2
	 * @return MMD value
	 */
	public double getPCADrift(Map<double[], Set<Integer>> dataChunk1, Map<double[], Set<Integer>> dataChunk2) {
		/**
		 * For dataChunk1, if dataChunk1 size is less than the given value, then X size
		 * is set to be dataChunk1.size.
		 */
		double[][] X;
		if (dataChunk1.size() <= ParametersUtil.C) {
			X = new double[dataChunk1.size()][];
			X = MathMethodUtil.getMaptoArraybySize(dataChunk1, dataChunk1.size());// Map to Array
		} else {
			X = new double[ParametersUtil.C][];
			X = MathMethodUtil.getMaptoArraybySize(dataChunk1, ParametersUtil.C);// Map to Array
		} // end_of_if

		/** For dataChunk2 */
		double[][] Y = new double[dataChunk2.size()][];
		Y = MathMethodUtil.getMaptoArray(dataChunk2);// Map to Array

		/** Get eigenvalues and eigenvectors: get(0) and get (1) */
		DoubleMatrix dx = new DoubleMatrix(X);// X 转矩阵
		DoubleMatrix dy = new DoubleMatrix(Y);// Y 转矩阵
		double[] xEigVector = getPCABean(dx);// 获取最大特征值对应的特征向量
		double[] yEigVector = getPCABean(dy);

		double ang = MathMethodUtil.getInnerproduct(xEigVector, yEigVector);
		return Math.acos(ang);
	}// end_of_getMMD

	private double[] getPCABean(DoubleMatrix d) {
		// C=X*X^t/m     矩阵*矩阵^异或/列数
		DoubleMatrix covMatrix = d.transpose().mmul(d).div(d.rows);// 求协方差
		/** 此部分花时很长 理论上是 n^3*/
		ComplexDoubleMatrix[] eigVectorsVal = Eigen.eigenvectors(covMatrix);// 特征向量+特征值, 可直接输入d
		ComplexDoubleMatrix eigVectors = eigVectorsVal[0];
		ComplexDoubleMatrix eigVals = eigVectorsVal[1];
		// 获取最大的特征值及对应的特征向量
		double tempMaxEigVal = eigVals.get(0).real();
		double[] tempVector = eigVectors.getColumn(0).data;
		for (int i = 1; i < eigVectors.columns; i++) {
			if (tempMaxEigVal < eigVals.get(i * (eigVals.getColumns() + 1)).real()) {
				tempVector = eigVectors.getColumn(i).data;// get its eigVectors
			}
		} // end_of_for
		return tempVector;
	}// end_of_getPCABean()
}