package com.GC3S.commonTools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Map.Entry;

/**
 * @ClassName: GetNewConcepts
 * @Description: Gets concept space from the original datasets
 * @author Dr. YunlongMi
 * @date Jue. 2, 2020
 * @since jdk1.8
 */
public class GetNewConcepts {
	HashMap<double[], Set<Integer>> map = new HashMap<double[], Set<Integer>>();

	/**
	 * @param instanceList
	 * @return gets conceptList
	 */
	@SuppressWarnings("unchecked")
	public List<Map<double[], Set<Integer>>> getNewConcepts(List<HashMap<Integer, double[]>> instanceList) {
		/** Updates concept pools by different labels. */
		List<Map<double[], Set<Integer>>> conceptList = new ArrayList<Map<double[], Set<Integer>>>();
		HashMap<double[], Set<Integer>> lMap = new HashMap<double[], Set<Integer>>();// Saves concept sub-pools.
		for (int i = 0; i < instanceList.size(); ++i) {// Initial conceptList
			conceptList.add(new HashMap<double[], Set<Integer>>());
		} // end_of_for
		for (int type = 0; type < instanceList.size(); ++type) {// type表示是第几类，若 type=0 表示第1类
			if (instanceList.get(type).size() != 0) {
				HashMap<Integer, double[]> instances = instanceList.get(type);// Gets instances for class "type".
				lMap = constructConceptSpace(instances);
				conceptList.get(type).putAll((Map<double[], Set<Integer>>) lMap.clone());// Copies concepts to pools.
				lMap.clear();
			} // end_of_if
		} // end_of_for
		return conceptList;
	}// end_of_getNewConcepts

	/**
	 * @details Gets a concept from an object and its corresponding attribute
	 *          values, and then extent.
	 * @param conceptMap
	 * @return concept with map form
	 */
	@SuppressWarnings("unchecked")
	private HashMap<double[], Set<Integer>> constructConceptSpace(HashMap<Integer, double[]> instances) {
		HashMap<double[], Set<Integer>> tempLMap = new HashMap<double[], Set<Integer>>();// intent-extent
		TreeSet<Integer> objectSet = new TreeSet<Integer>();// Saves extent of a concept
		Set<Entry<Integer, double[]>> pseudoConcepts = instances.entrySet();// Gets all instances for type
		for (Entry<Integer, double[]> concept : pseudoConcepts) {
			double[] attributeList = concept.getValue();// intent
			if (!tempLMap.containsKey(attributeList)) {// If it does not exist in the concept pool
				objectSet = getObjectSet(pseudoConcepts, attributeList);// Gets extent by its intent
				tempLMap = getConceptSet((TreeSet<Integer>) objectSet.clone(), attributeList, 0.8);
			} // end_of_if
			objectSet.clear();
		} // end_of_for
		return tempLMap;
	}// end_of_constructLatticeNode

	/**
	 * @param concepts
	 * @param attributeList
	 * @return extent with objects
	 */
	private TreeSet<Integer> getObjectSet(Set<Entry<Integer, double[]>> concepts, double[] attributeList) {
		TreeSet<Integer> objectSet = new TreeSet<Integer>();
		for (Entry<Integer, double[]> concept : concepts) {
			int row = concept.getKey();// extent
			double[] ins = concept.getValue();// intent
			boolean flag = true;
			for (int i = 0; i < attributeList.length; ++i) {
				if (!(ins[i] >= attributeList[i])) {
					flag = false;
					break;
				}
			} // end_of_for_attributeList
			if (flag) {
				objectSet.add(row);
			} // end_of_if
			flag = true;
		} // end_of_for_endRowNum
		return objectSet;
	}// end_of_getObjectSet

	/**
	 * @param objectSet
	 * @param attributeList
	 * @param al
	 * @return concept: <key,value>-<intent,extent>, and it is different from
	 *         classical concepts.
	 */
	private HashMap<double[], Set<Integer>> getConceptSet(TreeSet<Integer> objectSet, double[] attributeList,
			double al) {
		@SuppressWarnings("unchecked")
		HashMap<double[], Set<Integer>> tempMap = (HashMap<double[], Set<Integer>>) map.clone();
		boolean isUnion = true;
		/** 在此进概念聚类，按概念生成的顺序进行 */
		if (tempMap.size() != 0) {// It is not the first time, and it means tempMap is greater than 0.
			for (Entry<double[], Set<Integer>> entry : tempMap.entrySet()) {
				double[] key = entry.getKey(); // gets intent
				Set<Integer> value = entry.getValue(); // gets extent
				/**
				 * 序关系判定:(1) objectSet大于value，即A大于B结构;(2)objectSet小于value，即A小于B结构.
				 * 注意：是存在这着序关系后才确定是否在于theta值，不是任意两个对象都可以比较。
				 */
				if (objectSet.containsAll(value)) {
					int union = objectSet.size();
					int intersection = value.size();
					double theta = (double) intersection / union;
					/** 进行合并：对象取并，属性取均值: 1.只有存在序关系才合(若A大于B,则有AIB=B)；2.只有大于theta值合并 */
					if (theta >= al) {
						isUnion = false;
						double[] attribueAve = getAve(key, attributeList);
						map.remove(key);// 去掉被合并前的原有概念 can improve the performance
						map.put(attribueAve, objectSet);// intent-extent
						attributeList = attribueAve;
					}
				} else if (value.containsAll(objectSet)) {// 当 theta 较小时,单个样本过度融合进去,效果不佳
					int union = value.size();
					int intersection = objectSet.size();
					double theta = (double) intersection / union;
					if (theta >= al) {
						isUnion = false;
						double[] attribueAve = getAve(key, attributeList);
						map.put(attribueAve, value);// attributeList = attribueAve不成立;
						break;// 若某个概念包括生成概念则认为不需要再融合进去
					}
				} // end_of_if
			} // end_of_for
			if (isUnion) {// It is an atomic concept.
				map.put(attributeList, objectSet);
			}
		} else {// The first time, tempMap=0 due to map=0.
			map.put(attributeList, objectSet);
		} // end_of_if
		return map;
	}// end_of_getConceptSet

	/**
	 * @param value2
	 * @param attributeList2
	 * @return get the average value of two vectors
	 */
	private double[] getAve(double[] value2, double[] attributeList2) {
		double[] attributeList = new double[attributeList2.length];
		for (int index = 0; index < value2.length; ++index) {
			double value = (value2[index] + attributeList2[index]) / 2;
			attributeList[index] = value;
		} // end_of_for
		return attributeList;
	}// end_of_getAve
}
