package com.GC3S.commonTools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ExecutionException;
import com.GC3S.utils.ParametersUtil;

/**
 * @ClassName: UpdateConceptSpace
 * @Description: 更新需保存原来的概念，人的记忆在形成新的概念时同时保留了旧的概念。
 * @author Dr. Yunlong Mi
 * @date Feb. 27, 2021
 * @since jdk1.8
 */

public class UpdateConceptSpace {
	/**
	 * @details Add the new forming concepts into the original concept pools.
	 * @param conceptPoolList
	 * @param errorIntentList
	 * @param errorConceptList
	 * @param conceptList
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public void updateConceptList(ArrayList<Map<double[], Set<Integer>>> conceptPoolList,
			List<double[]> errorIntentList, List<Map<double[], Set<Integer>>> conceptList)
			throws InterruptedException, ExecutionException {
		/** Remove error concepts from the existing concept pools. */
		for (int i = 0; i < conceptPoolList.size(); ++i) {
			for (int j = 0; j < errorIntentList.size(); ++j) {
				Map<double[], Set<Integer>> conceptMap = (HashMap<double[], Set<Integer>>) conceptPoolList.get(i);
				if (conceptMap.containsKey(errorIntentList.get(j))) {
					conceptPoolList.get(i).remove(errorIntentList.get(j));
				} // end_of_if
			} // end_of_for
		} // end_of_for

		/**
		 * Delete the former concepts when subconcept size is greater than the given
		 * value and add concepts into concept pools.
		 */
		for (int i = 0; i < conceptList.size(); ++i) {
			/** Delete the former concepts */
			if (conceptPoolList.get(i).size() >= ParametersUtil.conceptSZ) {
				int count = 0;
				Iterator<Entry<double[], Set<Integer>>> it = conceptPoolList.get(i).entrySet().iterator();
				while (it.hasNext()) {
					it.next();
					it.remove();
					count++;
					if (count == ParametersUtil.C) {
						break;
					} // end_of_if
				} // end_of_while
			} // end_of_if (conceptPoolList.get(i).size() >= ParametersUtil.conceptSZ)
			/** Add concepts into concept pools */
			if (conceptList.get(i).size() != 0) {
				conceptPoolList.get(i).putAll(conceptList.get(i));
			} // end_of_if
		} // end_of_for
			// errorIntentList.clear();
			// conceptList.clear();
	}// end_of_updateConceptList
}